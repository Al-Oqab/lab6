package triangle;

import javax.swing.*;
import java.awt.*;

public class SierpinskiPanel extends JPanel {

    private final int MAX_DEPTH = 6;
    private final Color[] COLORS = {
            Color.RED, Color.GREEN, Color.BLUE, Color.MAGENTA,
            Color.ORANGE, Color.CYAN, Color.PINK
    };

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int width = getWidth();
        int height = getHeight();

        Point top = new Point(width / 2, 50);
        Point left = new Point(100, height - 100);
        Point right = new Point(width - 100, height - 100);

        drawSierpinski(g, top, left, right, MAX_DEPTH);
    }

    private void drawSierpinski(Graphics g, Point p1, Point p2, Point p3, int depth) {
        if (depth == 0) {
            int[] x = {p1.x, p2.x, p3.x};
            int[] y = {p1.y, p2.y, p3.y};
            g.setColor(COLORS[0]);
            g.fillPolygon(x, y, 3);
            return;
        }

        g.setColor(COLORS[depth % COLORS.length]);
        int[] xPoints = {p1.x, p2.x, p3.x};
        int[] yPoints = {p1.y, p2.y, p3.y};
        g.fillPolygon(xPoints, yPoints, 3);

        Point m1 = midpoint(p1, p2);
        Point m2 = midpoint(p2, p3);
        Point m3 = midpoint(p3, p1);

        g.setColor(getBackground());
        int[] mx = {m1.x, m2.x, m3.x};
        int[] my = {m1.y, m2.y, m3.y};
        g.fillPolygon(mx, my, 3);

        drawSierpinski(g, p1, m1, m3, depth - 1);
        drawSierpinski(g, m1, p2, m2, depth - 1);
        drawSierpinski(g, m3, m2, p3, depth - 1);
    }

    private Point midpoint(Point a, Point b) {
        return new Point((a.x + b.x) / 2, (a.y + b.y) / 2);
    }
}
